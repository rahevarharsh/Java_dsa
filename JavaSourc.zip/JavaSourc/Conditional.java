import java.util.Scanner;

public class Conditional {
    public static void main(String[] args) {
       float a=20.53f;
        System.out.println(a);
    }
}
