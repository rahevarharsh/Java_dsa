import java.util.ArrayList;

public class Design_HashSet {
    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList<>();
        al.add(1);
        al.add(2);
        al.add(3);
        al.add(4);
        al.add(5);
        System.out.println(al);
        System.out.println(al);
    }
}
//class MyHashSet {
//
//    public MyHashSet() {
//
//    }
//
//    public void add(int key) {
//
//    }
//
//    public void remove(int key) {
//
//    }
//
//    public boolean contains(int key) {
//
//    }
//}