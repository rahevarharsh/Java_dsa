//public class StringOpration {
//    public int finalValueAfterOperations(String[] operations) {
//        int val = 0;
//    }
//
//    public static void main(String[] args) {
//
//    }
//}
