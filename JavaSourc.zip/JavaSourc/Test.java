public class Test {
    public static void main(String[] args) {
        String s = "harsh";
        String s2 = s;
        String s3 = new String("harsh");
        System.out.println(s3.equals(s));
    }
}
