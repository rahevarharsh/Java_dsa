public class Cy {
    public static void main(String[] args) {

        for (int i = 0; i < 1000; i++) {
            float s=(1+i*96)/7f;
            System.out.println(i+" "+s);
        }
    }
}
