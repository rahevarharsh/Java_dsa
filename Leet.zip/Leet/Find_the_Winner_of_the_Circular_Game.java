//public class Find_the_Winner_of_the_Circular_Game {
//    public static void Index(int n,int l){
//        int []arr = new int[n];
//        for (int i = 0; i <l ; i++) {
//-
//        }
//    }
//
//    public static void main(String[] args) {
//
//    }
//}
