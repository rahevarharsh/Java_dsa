//public class C3 {
//
//    public void allPrmu(String s){
//        for (int i = 1; i < s.length() ; i++) {
//            for (int j = 0; j <s.length() ; j++) {
//                Integer.parseInt(s[j]);
//            }
//        }
//    }
//
//    public static void main(String[] args) {
//
//    }
//}
